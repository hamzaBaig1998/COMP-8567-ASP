#include <stdio.h>

void main()
{
    float x;
    printf("Enter the value of x: ");
    scanf("%f", &x);

    printf("The value of x is %f\n", x);
}