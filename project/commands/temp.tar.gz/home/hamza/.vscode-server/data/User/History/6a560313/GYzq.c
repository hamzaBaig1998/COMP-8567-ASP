
#include <stdio.h>

void main()
{
    put("This is print through put");
    printf("This is print through printf");
}