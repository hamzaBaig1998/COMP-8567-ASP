#include <stdio.h>

void main()
{
    char animals[4][5] = {
        "Ant",
        "Cat",
        "Dog",
    }
}