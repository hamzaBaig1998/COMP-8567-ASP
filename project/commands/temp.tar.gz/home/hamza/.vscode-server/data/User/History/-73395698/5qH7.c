#include <stdio.h>
#include <string.h>

void main()
{
    char string[] = "I love programming";
    int len;

    len = strlen(string);
}