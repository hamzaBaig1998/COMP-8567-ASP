#include <stdio.h>

void main()
{
    // tolower as digit
    printf("this is a lower case example %d\n", 'A');
    // tolower as character
    printf("this is a lower case example %c\n", 'A');

    // toupper as digit
    printf("this is a upper case example %d\n", 'a');
    // toupper as character
    printf("this is a upper case example %c\n", 'a');
}