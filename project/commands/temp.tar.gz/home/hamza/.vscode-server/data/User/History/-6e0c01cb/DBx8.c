#include <stdio.h>

void main()
{
    // for loop
    printf("For Loop\n");
    for (int i = 0; i < 10; i++)
    {
        printf("Item: %d\n", i);
    }
}