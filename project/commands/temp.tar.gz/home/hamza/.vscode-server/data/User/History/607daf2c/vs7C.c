#include <stdio.h>
#include <math.h>

void main()
{
    float x;

    x = sqrt(12);

    printf("The square root of 12 is %f /n", x);
}