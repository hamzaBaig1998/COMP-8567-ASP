#include <stdio.h>

void main()
{
    int x;
    printf("Enter the value of x: ");
    scanf("%d", &x);

    printf("The value of x is %d\n", x);
}