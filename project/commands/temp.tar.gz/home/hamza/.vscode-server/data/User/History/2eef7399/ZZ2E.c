#include <stdio.h>

void main()
{
    printf("It's simple maths, %d + %d = %d\n", 2, 2, 2 + 2);
    printf("I am a %c %s", 'C', " Programmer.\n");
    printf("%%d is used as an integer placeholder\n");
    printf("%%s is used as a string placeholder\n");
    printf("%%f is used as a float placeholder\n");
    printf("%%c is used as an character placeholder\n");
    printf("%%%% is used as a percentage placeholder\n");
}