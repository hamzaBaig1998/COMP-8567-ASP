#include <stdio.h>
#include <math.h>

void main()
{
    float x = 12;

    float s = sqrt(x);

    printf("The square root of %f is %f", x, s);
}