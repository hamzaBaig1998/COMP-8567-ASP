#include <stdio.h>
#include <math.h>

void main()
{
    int x = 12;

    float s = sqrt(12);

    printf("The square root of %d is %f /n", x, s);
}