#include <stdio.h>

void main()
{
    printf("This is the first line\n\"This is the second line.\"\n");
}