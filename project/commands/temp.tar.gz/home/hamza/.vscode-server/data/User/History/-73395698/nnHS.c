#include <stdio.h>

void main()
{
    char string[] = "I love programming";
    int len;

    len = strlen(string);
}