#include <stdio.h>

void main()
{
    printf("It's simple maths, %d + %d = %d\n", 2, 2, 2 + 2);
    printf("%%d is used as an integer placeholder");
}