#include <stdio.h>

void main()
{
    // to lower as digit
    printf("this is a lower case example %d", 'A');
    // to lower as character
    printf("this is a lower case example %c", 'A');
}