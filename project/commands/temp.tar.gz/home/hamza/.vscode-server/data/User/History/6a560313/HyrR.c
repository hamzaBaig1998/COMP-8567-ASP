
#include <stdio.h>

void main()
{
    puts("This is print through put");
    printf("This is print through printf");
}