"use strict"
// This file exists so that we can package the extension pack as a workspace-only extension.
// The most important extensions in the pack do not work for the web scenario, so we do not want this pack to appear for web.
console.log('do not activate');
